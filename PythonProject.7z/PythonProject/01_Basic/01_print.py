print('가',end='~')
print('가나다',end='\n')
a=10
print(a)
print('오늘은' + '즐거운' + '금요일' + '입니다.')
print('오늘은' '즐거운' '금요일'  '입니다.')
print('오늘은' , '즐거운' ,'금요일' , '입니다.')
print(12+34)
print("12+34")
print("12"+"34")
print(12 + (int)("34"))
print("12" + (str)(34)) #34=>"34"
print(type(12))
print(type("12"))

print("%d / %d = %d" % (10,3,10/3))
print("%d / %d = %f" % (10,3,10/3))
print("%d / %d = %.2f" % (10,3,10/3))
print("%d / %d = %5d" % (10,3,10/3))
print("%s" % "python")
print("#@!" * 3)
print(15/6)
print(15//6)
print(15%6)
print(divmod(15,6)) # (2, 3) 튜플

a=5
b=10
print((0>a) or (a<b))
print((0>a) and (a<b))

name = "아이유"
age = 30
height = 189.2

print("이름: ", name)
print("나이: ", age)
print("키: ", height)

print("이름: %s" % name )
print("나이: %d" % age )
print("키: %.1f" % height )

print("이름 : " + name)
print("나이 : " + (str)(age))
print("키 : " + (str)(height))

