print("입력하세요:",end='')
a = int(input()) # 10
print('a:',a)
print(type(a)) # "10"

b = input("입력:") # 20
print('b:',b)

# 10+20=30
print(a,"+",b,"=",a+(int)(b)) # 10 +"20"
print(a,"+",b,"=",(int)(a)+(int)(b))

c = float(input("키 입력:"))
print('c:',c)

print("나이는 10살이고 키는 123.4입니다.")
print("나이는 {}살이고 키는 {} 입니다.".format(a,c))
print("나이는 {0}살이고 키는 {1} 입니다.".format(a,c))
print("나이는 {1}살이고 키는 {0} 입니다.".format(a,c))
print("나이는 {x}살이고 키는 {y} 입니다.".format(x=a,y=c))

