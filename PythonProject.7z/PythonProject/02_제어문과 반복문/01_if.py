
su = 10
# if(su%2==0){
#   syso(짝수)
#    syso(하하하)
# }else if(조건){
#     syso(홀수)
#     syso(호호호)
# }else if(조건){
#
# }else{
#
# }
if su % 2 == 0 :
    print(su,"짝수")
    print("하하하")
else :
    print(su,"홀수")
    print("호호호")
print("헤헤헤")

# if :
# elif :
# elif:
# else:

# 점수 입력
# 90점 이상 A학점
# 80점 이상 B학점
# F학점

score = int(input("점수를 입력하세요 : "))
if score >= 90:
    print("A 학점")
elif score >= 80: # if 80 <= score < 90
    print("B 학점")
elif score >= 70:
    print("C 학점")
elif score >= 60:
    print("D 학점")
else:
    print("F 학점")


# 80점 이상 Pass, Fail
if score >= 80:
    print('Pass')
else:
    print('Fail')

result = 'Pass' if score >= 80 else 'Fail'
print(result)

result2 = 'A' if score >= 90 else \
            'B' if score >= 80 else \
            'C' if score >= 70 else \
            'D' if score >= 60 else \
            'F'
print(result2)

result3 =( 'A' if score >= 90 else
            'B' if score >= 80 else
            'C' if score >= 70 else
            'D' if score >= 60 else
            'F')
print(result3)
