for i in range(1,5): # i가 1 <= 5
    print(i)

for i in range(5): # 0 <= i < 5 #range(0,5,1) 3번째 인자는 몇씩 증가시킬건지
    print(i,end=' ')

print('---------')

sum = 0
for i in range(1,11):
    sum = sum + i

print(sum)
#print("sum:"+sum) #이렇게 하면 오류 문자열 + 정수 는 불가능
print("sum:"+str(sum)) #이렇게 해야 정상적작동
print("sum:",sum)
print("sum:%d" % sum)
print(f"sum : {sum}")
print("1 ~ 10 합계 : {}".format(sum))
print("1 ~ 10 합계 : {0}".format(sum))
print("1 ~ 10 합계 : {sum}".format(sum = sum))

sum = 0
for i in range(5,0,-1):
    print(i,end=' ')
    sum = sum + i
    sum += i
print('\n-------------------')

oSum = 0
eSum = 0

for i in range(1,11):
    if i % 2 == 0:
        oSum += i
    elif i % 2 == 1:
        eSum += i

print('\n',oSum, eSum)

for i in range(1,11):
    if i > 5:
        break
    print(i,end=' ')
print('\n')

for i in range(1,11):
    if i == 5:
        continue
    print(i,end=' ')

for i in range(2,10):
    print('--%d단--'%i)
    #print('--',i,'단--')
    for j in range(2,10):
        print("%d*%d=%d"%(i,j,i*j))
        print('{0} * {1} = {2}'.format(i,j,i*j))
    print('------------')

star = int(input("숫자입력:"))
for i in range(1,star):
    for j in range(0,i):
        print("*",end='')
    print()
