total = 0
i = 0
print(i<11)

while i<11:
    total = total + i
    i +=1
print(total)

total = 0
count = 0
while True:
    a = int(input("숫자를 입력하세요:"))
    if a > 0:
        total += a
        count += 1
    else:
        break
print("합계 : {}".format(total))
print("평균 : {}".format(total/count))
print("평균 : {:.2f}".format(total/count))
print("평균 : %.2f" %(total/count))
#print("평균:%f" % round(total/count,2))





