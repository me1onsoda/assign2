i = 1
while i<11:
    print(i)
    i +=1
    if i==5:
        break
else :
    print("else")
print("finish")

for i in range(1,10):
    print(i)
else: #반복문이 중간에 끊기지않고 정상적으로 전부 반복되었을때 else실행됨
    print("else")
print("finish")