a =1
print(type(a))
b = "123"
print(type(b))
c=True
print(type(c))

L=[10,20,30] #변경 가능
L[1] = 22
#L[3]=100 #하지만 이렇게 없는방에 추가는 불가능
L.append(44) #할거면 이렇게 새로추가
print(L)
print(type(L))
print(L)
print(L[0])
# print(L[3])
print(L[-1])
print(L[2])
print(L.__len__()) #리스트 길ㅇ
print(len(L))

for i in range(0,len(L)):
    print("%d번방"%i,L[i])

for i in L:
    print(i)

print(L+L)
print(L*3)

