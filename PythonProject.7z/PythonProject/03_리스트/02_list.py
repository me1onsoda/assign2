# L = [0,1,2,3,4,5,6,7,8,9]
# L = range(1,10)
L = list(range(1,10))
print(L)
print(L[1:5]) #1번부터 5번방 직전까지
print(L[1::3]) #1번부터 3번째씩
print(L[5:]) #5번부터 끝까지
print(L[:5]) #0번부터 5번까지
print(L[::2]) #2번째단위 2 4 6
print(L[::-2]) #2번째단위인데 뒤부터

print(3 in L)
print(3 in L[::2])  #있는가? 없는가? bool반환
L1 = ['apple', 'banana', 'orange' ,100 ,200] #다른 타입도 함께 저장가능함
print(L1)
print(L1[1])
L1[1] = "baaaanaaanaaaa"
print(L1)
L1[1:1] = [9] #1부터 1전까지 없애고 9하나넣기 (1전에 하나 넣겠다)
print(L1)
L1[1:2] = [1,2,3,4,5]
print(L1)
L1[1:2]=[50] #특정범위에 넣을땐 넣을값을 []로 둘러싸야함
print(L1)

del L1[2]
print(L1)

L2= L1
print(L2)
L2[1] = 99
print(L1) #L2를 바꿨는데 L1도 바뀜 -> L2=L1할때 값을 전달하는게 아니라 리스트의 주소를 넘겨준다는 뜻

