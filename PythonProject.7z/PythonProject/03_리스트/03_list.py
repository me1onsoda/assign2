L=[10,20,30]
# L[2:2] = [25]
# print(L)

L.insert(2,25)
print(L)

L[4:4] = [44]
L.append(44)
print(L)

L = []
for i in range(1,6):
    #a = int(input("숫자를 입력하세요:"))
    L[i:i] = [32]
    # L[i:] = [a]
    # L.append(a)

print(L)

print(L.index(32))
print(L.count(32))

L.sort(reverse=True) #내림차순 정렬 false는 오름차순
print(L)
L2 = sorted(L) #이거는 주소주는게 아니라 정렬후에 새로 리스트 만들어서 넣어줌 원본은 그대로
print(L2)
print(L)

L=['blueberry', 'apple','Grape','banana']
L.sort() #내림차순이니까 대문자 먼적
print(L)

L=['123','34','56','2345']
L.sort()   #이러면 단순히 소문자 -> 대문자 순으로 ->문자로 인식하니까
print(L)
L.sort(key=int) #이러면 숫자크기로
print(L)

L.clear()
print(L)
