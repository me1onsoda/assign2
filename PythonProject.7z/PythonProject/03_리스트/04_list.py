L = [['apple','banana'],[10,20,30]]
print(L)
print(L[0][0])
print(len(L)) #행 길이

for i in L:
    for j in i:
        print(j)

for i in range(0,len(L)):
    for j in range(0,len(L[i])):
        print(L[i][j],end=' ')
    print()