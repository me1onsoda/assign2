l = list(range(0,10))
l1 = [i for i in range(0,10)]
print(l)
print(l1)

jumsu = [90,25,67,45,80]
print(jumsu)
print(sum(jumsu))

for i in enumerate(jumsu):
    print(i) #하나하나를 몇번방에 뭐있는지 나오게

for i,j in enumerate(jumsu,start=1): #i가 1부터시작 원래는 0부터
    print(i,j)