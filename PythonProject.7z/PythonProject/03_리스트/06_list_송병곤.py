students = [["kim",90,87],
           ["park",78,81],
           ["choi",65,70],
           ["jung",85,92],
           ["hong",88,94]]
print(students)
#이름 점수 점수 평균 학점
#이름 기준 오름차순 정렬 , 대문자로

for student in students:

    avg = (student[1]+student[2])/2.0
    avg = sum(student[1:])/len(student[1:])
    if avg>=90:
        grade = "A"
    elif avg>=80:
        grade = "B"
    elif avg>=70:
        grade = "C"
    elif avg>=60:
        grade = "D"
    else:
        grade = "F"

    upperName = student[0].upper()

    student[0] = upperName
    student.append(avg)
    student.append(grade)

print(sorted(students))

from pprint import pprint
pprint(students)