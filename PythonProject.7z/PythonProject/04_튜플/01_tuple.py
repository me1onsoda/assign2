t = (1,2,3,4,5)
print(t)
print(type(t))
print(len(t))
for i in range(0,len(t)):
    print(t[i])

#t[2]=7 #튜플은 변경불가능 #리스트와 다름
#그 외에는 전부 리스트와 동일