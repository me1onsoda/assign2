#튜플
t1 = ()
t2 = (1,2,3)
t3 = 1 ,2, 3
t4 = (1,)
t5 = 1,

#int
t6 = (1)
t7 = 1
print(type(t1))
print(type(t2))
print(type(t3))
print(type(t4))
print(type(t5))
print(type(t6))
print(type(t7))

t = (1,2,3)
print(t[0])

t2 = t + ('kim','park')
print(t2) #이러면 걍 추가

t2 = t ,('kim','park')
print(t2) #이러면 이중 튜플

x,y,z = 1,2,3
print(x,y,z)

x,y = y,x #자리 스왑
print(x,y)

p,q,r = t
print(p,q,r)

L = list(t)
print(L)
L[0] = 99 #튜플을 잠깐 리스트로 바꿨다가 변경후 튜플로 why?튜플은 수정이 안되니까
print(L)

t3 = tuple(L)
print(t3)