#map 비슷한거 키와 값

d={'one':'hana','two':'dul','three':'set'} #사전
print(type(d))
print(d)
print(d.get('one'))
print(d['two'])

d['four']='net'
print(d)
print(d)
print(len(d))
print(len(d['four'])) #키에 해당하는 값의 len
print(len(d.keys())) #키 몇개
print(len(d.values()))
print('one' in d.keys())
print('dul' in d.values())
print(len(d.items())) #튜플 개수

for i in d.items():
    print(i)
for i,j in d.items():
    print(i,j)

print()
word1="Hello"
word2="World~~"
d={}
d[word1]=len(word1)
d[word2]=len(word2)
print(d)