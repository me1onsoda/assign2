mb1 = {"kim":33, "park":44,"choi":55}
mb2 = {"kim":77, "jung":88,"hong":99}

print(mb1['park'])
print(mb2['park']) #이건 오류나는데
print(mb2.get('park')) #이건 없으면 그냥 none으로 출력
print(mb2['kim'])

