# quit을 입력할때까지 이름,나이입력

person = {}

while True:
    name = str(input("이름:"))
    age = int(input("나이:"))
    person[name]=age

    next_input = str(input("계속?"))
    if next_input == "quit":
        break

print(person)

total = 0
for age in person.values():
    total += age

age_sum = sum(person.values())

print(total)
print(age_sum)

while True:
    searchName = str(input("이름으로 검색:"))
    if searchName == "stop":
        break
    for savedName in person.keys():
        if savedName.upper() == searchName.upper():
            print(person[savedName])
    if person.get(searchName) == None:
        print("없음")
