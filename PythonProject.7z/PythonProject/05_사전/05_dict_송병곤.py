scores = {'윤아':{"국어":85,"수학":92,"영어":78},
         '정국':{"국어":43,"수학":76,"영어":92},
         '태연':{"국어":32,"수학":77,"영어":98},
         '보검':{"국어":98,"수학":42,"영어":88},}
#학생별 평균
#평균이 70점 이상인 학생
#평균 내림차순으로 정렬
#과목별 최고점수

maxKor = 0
maxMath = 0
maxEng = 0
avgStudent = {}
print(scores)
print("--학생별 평균--")
for name,score in scores.items():
    scoreAvg = round(sum(score.values())/3.0, 2)
    print(name,":",scoreAvg)
    avgStudent[name]=scoreAvg

    if maxKor < score.get("국어"):
        maxKor = score.get("국어")
    if maxMath < score.get("수학"):
        maxMath = score.get("수학")
    if maxEng < score.get("영어"):
        maxEng = score.get("영어")


print("\n--평균 70이상 학생--")
moreThanScore = {}
for name,score in avgStudent.items():
    if score >= 70:
        moreThanScore[name] = score
print(moreThanScore)
print()
print(dict(filter(lambda x: x[1] >= 70, avgStudent.items()))) #lambda로 하는법

dict(filter(lambda item: item[1] >= 70, map( lambda item: (item[0], round(sum(item[1].values()) / len(item[1]), 2)),scores.items())))

print("\n--평균 내림차순 정렬--")
print(sorted(avgStudent.items(), key=lambda item: item[1], reverse=True))

print("\n--과목별 최고점수 학생--")
maxScoreName = {}
for name,scores in scores.items():
    if scores["국어"] == maxKor:
        maxScoreName["국어"] = name
    if scores["수학"] == maxMath:
        maxScoreName["수학"] = name
    if scores["영어"] == maxEng:
        maxScoreName["영어"] = name

print(maxScoreName)
