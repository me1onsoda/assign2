def add(a, b):
    print(add)
    return a + b

result = add(1, 2)
print(result)
a=[1,2,3]
b=[4,5,6]

print(add(a,b)) #리스트 연결

def func():
    pass

result = func()
print(result) #Nonce

def func2(x,y,z):
    return x+y+z
print(func2())