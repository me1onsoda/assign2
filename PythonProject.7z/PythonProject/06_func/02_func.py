def func(*args): #*을 사용해서 무슨 변수든 받을수있게 가능
    for i in args:
        print(i, end="/")
    print()

func() #*로 처리한 변수는 넣지않아도 함수 실행가능
func(1,2)
func([1,2,3],(4,5,6))
func("apple","banana","orange")

def func2(a,*args):
    for i in args:
        print(i, end="/")
    print()

# func2() #$이럴땐 a에 들어갈 변수 하나는 있어야함
func2(1,2)
func2([1,2,3],(4,5,6))
func2("apple","banana","orange")

tp =(1,2,3)
def func3(a,b,c):
    print(a,b,c)
func3(tp[0],tp[1],tp[2])

def func4(a,b,c):
    print(a,b,c)

func4(*tp) #튜플을 통으로 넘길떄는 그냥 앞에 *을 붙이면 알아서 하나하나 넣어줌

d = {'a':10,'b':20,'c':30}
def func5(a,b,c):
    print(a,b,c)

func5(*d) #사전의 key가 넘어감 a b c
func5(**d) #이러면 value가 넘어감

def func6(a):
    if a == 1:
        return 1
    elif a>1:
        return a + func6(a - 1)
    else:
        return None

print(func6(5))

def func7(x):
    if x =='a':
        y= 'b'
    else:
        y = 'a'
    return {
        'a' : 1,
        'b' : 2
    }.get(y,100) #x에 들어온값에 따라서 return을 다르게 #,뒤에는 조건에 없는값이 들어왔을때 리턴할값

print(func7('a'))
print(func7('b'))
print(func7('c'))

