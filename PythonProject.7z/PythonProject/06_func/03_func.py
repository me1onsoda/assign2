def func():
    x=30
    print(x)

func()

y=10
def func2(y):
    y=y*y
    print(y)
    global k
    k = 10
    print("func2 k :",k)

func2(y)
print(y)
print(k)
