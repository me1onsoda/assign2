def func2(x):
    return x**2 #제곱


print(func2(4))

a = lambda x : x**2
print(a(5))

b= lambda x,y,z : x+y+z
print(b(5,6,7))

L = [1,2,3,4,5]
result = list(map(lambda x : x ** 2, L) )#map (함수, 작업대상)
print(result)

fruit = ['apple', 'banana', 'cherry', 'kiwi']
result2 = list(map(lambda x : len(x), fruit) )
print(result2)

a = [1,2,3]
b = [10,20,30]
result3 = list(map(lambda x,y : x+y, a,b)) #a는 x로 b는 y로
print(result3)

L = [13,16,11,15,14]
result4 = list(map(lambda x: "짝수" if x % 2 == 0 else "홀수", L))
result6 = list(filter(lambda x : x % 2 == 0, L))
print(result4)
print(result6)

result5 = list(map(lambda x: (x.upper(), len(x)), fruit))
print(result5)

result4 = list(filter(lambda x: len(x) >= 6, fruit))


students = [["kim",90,87],
           ["park",78,81],
           ["choi",65,70],
           ["jung",85,92],
           ["hong",88,94]]

result7 = list(filter(lambda x : x[1] >= 80, students))
print(result7)

result8 = list(filter(lambda x : x[1] >= 80 and x[2] >=90, students))
print(result8)

result9 = list(map(lambda x : (x[0],(x[1]+x[2])/2.0), students))
print(result9)

result10 = list(filter(lambda s:((s[1]+s[2])/2)>=80,students))
print(result10)