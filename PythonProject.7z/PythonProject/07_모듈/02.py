def apple():
    print('apple')

apple()

import Ex01 #다른 파일의 함수를 쓰고싶을때 #전부 다 가져오기때문에 Ex01에 쓰여진 abc()도 가져옴
Ex01.abc()
Ex01.xyz()

import Ex01 as Ex_a #별칭 지정가능
Ex_a.abc()
Ex_a.xyz()

from Ex01 import abc,xyz #이렇게하면 파일명이나 별칭 상관없이 그냥 함수명 그대로 사용할수있다
abc()
xyz()

import myPkg.Ex01
print(myPkg.Ex01.add(1,2))

import myPkg.Ex01 as exPkg
print(exPkg.add(1,2))

from myPkg.Ex01 import add
print(add(1,2))




