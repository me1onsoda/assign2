def abc():
    print('abc')

def xyz():
    print('xyz')

print('__name__',__name__)
if __name__ == '__main__': #현재파일을 직접 실행시에만 if문실행
    abc()
    xyz()

