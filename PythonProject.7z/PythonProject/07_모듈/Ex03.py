import math
print(math.pi)
result = math.factorial(5)
print(result)

import math as m
print(m.sqrt(5)) #제곱근

from math import *
print(sqrt(5))

from math import factorial as f
print(f(5))

print(max(10,20,45,20))
print(min(10,20,45,20))
print(abs(-10))
print(pow(3,4))
print(round(2.7))

import datetime
print(datetime.date.today())

from datetime import *
now = datetime.now()
print(now)
print(now.year)
print(now.month)
print(now.day)
print(now.hour)
print(now.minute)
print(now.second)
print(now.microsecond)

print("%s년 %s월 %s일"% (now.year,now.month,now.day))
print("%d년 %d월 %d일"% (now.year,now.month,now.day))
print(datetime.weekday(now)) #0:월 1:화 ...

def week_today(now):
    week = ['월','화','수','목','금','토','일']
    weekDay = week[datetime.weekday(now)]
    return weekDay

print(week_today(now))



