import os
print(os.getcwd())
# os.chdir('./../')
print(os.listdir(".")) #현재위치에 있는 파일
print(os.listdir("..")) #현재위치 바로위에 뭐가있는지

# os.rename("a.txt","c.txt")
# os.rename("c.txt","my/d.txt")

# os.remove('b.txt')
# os.remove('my') #폴더 안에 파일이 있으면 삭제가 불가능

import shutil
# shutil.rmtree("my") #얘는 폴더안에 파일있어도 삭제가 가능함
shutil.copy("a.txt", "b.txt") 