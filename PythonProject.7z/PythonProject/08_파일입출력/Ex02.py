import os
print(os.getcwd())

# # open("test.txt","w") #w 없으면 생성 ,  있어도 새로 만들어서 덮어씌움
# f = open("test.txt","a") #a는 없으면 생성, 있으면 생성 x 기존파일 내용 그대로
# #현재파일과 txt파일과 연결 -> 연결명을 지정 (ex f로)
# f.write("hello world\n")
# f.close()

with open("test.txt","w") as f: f.write("hello world\n")
#with open쓰면 close자동으로 실행됨

f = open("test.txt","r") #r은 파일이 무조건있어야함. 없으면 오류!
pos = f.tell() #현재 파일 포인터 위치를 저장
print('pos:',pos)
print(f.read()) #eof까지 싹다읽음
pos = f.tell()
print('pos:',pos)
f.seek(1) #포인터 위치를 1론ㅁ
print(f.read())

f.close()
