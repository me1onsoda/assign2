# import os
# f = open("gugudan.txt","a")
# for i in range (1,10):
#     print('3 x {} = {}\n'.format(i, i * 3))
#     f.write('3 x {} = {}\n'.format(i, i * 3))
#
# f.close()

print("콘솔 구구단출력1")
f = open("gugudan.txt","r") #뒤에 모드의 기본값은 'r'
print(f.read())
print(type(f.read()))
f.close()

print("콘솔 구구단출력2")
f = open("gugudan.txt","r")
for line in f.readlines():
    print(line,end="")
f.close()

print("콘솔 구구단출력3")
f = open("gugudan.txt","r")
while True:
    line = f.readline()
    if line == '':
        break
    print(line,end='')
f.close()

print("콘솔 구구단출력5")
f = open("gugudan.txt","r")
lines = list(f.readlines())
print(lines)
print(type(lines))
f.close()