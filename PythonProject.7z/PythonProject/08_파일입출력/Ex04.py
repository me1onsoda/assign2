fr = open("grade.txt","r")
fw = open("grade_result.txt","w")

line = fr.readline()
fw.write(line)
pos = fw.tell()
fw.seek(pos-2)
fw.write("\t합계\n")

for line in fr.readlines():
    parts=line.split()

    # sumScore = int(parts[1]) + int(parts[2]) + int(parts[3])
    # newLine = line.strip() + "\t" + str(sumScore) + "\n"
    # fw.write(newLine)

    total = 0
    for i in range (1,len(parts)):
        total += int(parts[i])
    fw.write(line)
    pos = fw.tell()
    fw.seek(pos-2)
    fw.write("\t"+str(total)+"\n")

fw.close()
fr.close()
