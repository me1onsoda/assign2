#1990.txt 1988.txt 1992.txt 연도에맞는 txt 생성 후 입력

fr = open("members.txt","r",encoding="utf-8")

for line in fr:
    parts = line.split(",")
    fileName = parts[1][:4]+".txt"
    fw = open(fileName,"a",encoding="utf-8")
    fw.write(line)

fr.close()