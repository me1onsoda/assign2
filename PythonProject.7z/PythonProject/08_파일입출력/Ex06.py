import json

d = {'name':'아이유'  , 'age':40 , 'address':{"city":"서울", "gu":"종로구"}}
print(d)

print("name:",d['name'])
print("age:",d['age'])
print("city:",d['address']['city'])
print("gu:",d['address']['gu'])

fr = open("jumsu.json","r",encoding="utf-8")
readString = fr.read()
print(readString)
print(type(readString))
fr.close()

# 문자열(readString) -> dict타입으로 변환
jsonData = json.loads(readString)
print(jsonData)
print(type(jsonData))

t = ()
totalList = []
sumScore = 0
for person in jsonData:
    for i in person.keys():
        print(person[i],end=' ')
        if i != 0:
            if i !=4:
                sumScore += float(person[i])
                t += ((i, person[i]),)
                if i ==3:
                    t += (("total", sumScore),)
            if i ==4:
                if person[i] !="F":
                    gender="여자"
                else:
                    gender="남자"
                t += ((i, gender),)
        else:
            t += ((i,person[i]),)
        totalList.append(t)
    print()
print(totalList)

