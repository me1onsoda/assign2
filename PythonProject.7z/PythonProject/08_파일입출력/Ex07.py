#주민번호 생년원일 앞자리 두자리에서 12 89
#오라클에선 이게 50이상이면 19붙이고 50보다 작으면 20붙임

import json
from datetime import date

today = date.today()

fr = open("humans.json","r",encoding="utf-8")
readString= fr.read()

jsonData = json.loads(readString)

personList = []
for person in jsonData:
    personTuple = ()
    birthyear = person["ssn"][:2]
    if int(birthyear) >= 50:
        birthyear = "19"+birthyear
    else:
        birthyear = "20"+birthyear
    age = today.year - int(birthyear)

    genderCode = person["ssn"][7:8]
    if int(genderCode) == 2 or int(genderCode) == 4:
        gender = "여자"
    else:
        gender = "남자"

    for i in person.keys():
        if i == "blood":
            personTuple += (person[i]+"형",)
        else:
            personTuple += (person[i],)
        if i  == "name":
            personTuple += (age,)
        if i == "ssn":
            personTuple += (gender,)
    personList.append(personTuple)

print(personList)



