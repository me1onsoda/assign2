import  xml.etree.ElementTree as ET
# fr = open("student.xml","r",encoding="utf-8")
# xmlData= fr.read()
# print(xmlData)
#
# myroot = ET.fromstring(xmlData)
# print(myroot) #myroot안에 전체정보

tree = ET.parse("student.xml")
myroot = tree.getroot()
print(myroot)
print(myroot.tag) #이렇게 하면 태그명도 보여줌 

totalList = []
for stu in myroot.iter('student'):
    #stu에는 전체중에 student태그달린것 하나씩
    onePersson = []
    onePersson.append(stu.find("name").text)
    onePersson.append(stu.find("name").text)
    onePersson.append(stu.find("국어").text)
    onePersson.append(stu.find("영어").text)
    onePersson.append(stu.find("수학").text)
    sumScore = 0

    sumScore = float(stu.find("국어").text) +float(stu.find("영어").text) +float(stu.find("수학").text)
    onePersson.append(sumScore)
    print(onePersson)
    totalList.append(onePersson)

print(totalList)