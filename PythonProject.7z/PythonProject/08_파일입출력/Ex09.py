import xml.etree.ElementTree as ET
tree = ET.parse('Car_Info.xml')
myroot = tree.getroot()
# print(myroot.tag)

totalList = []
for info in myroot.iter('car'):
    oneCar = ()
    print("브랜드:"+info.find('brand').text,end=' ')
    print("모델:"+info.find('model').text,end=' ')
    print("제조년도:"+info.find('year').text,end=' ')
    print("색상:"+info.find('color').text)
    oneCar+=("브랜드",info.find('brand').text),
    oneCar+=("모델",info.find('model').text),
    oneCar+=("제조년도",info.find('year').text),
    oneCar+=("색상",info.find('color').text),
    print(info.find('brand').attrib['name'],end=' ')
    totalList.append(oneCar)

print(totalList)
