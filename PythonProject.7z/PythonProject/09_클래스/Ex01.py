def add():
    print("add")

class Person :
    lastname = "김" #클래스변수 객체간에 공유하는 변수 (java에서 클래스 static 변수)

    def setname(self, name): #클래스안의 함수는 매개변수 무조건 하나는 써야함 없으면 그냥 self해도 됨
        print("self:",self)
        #self = 클래스 자기자신의 주소가 들어감 이름이 바뀌어도
        self.name = name #이렇개 변수 선언도 가능
        self.fullname = self.lastname+self.name

    def setage(self,age):
        self.age = age

    def display(self,fruit):
        print("출력")
        print("lastname:",self.lastname)
        print("fullname:",self.fullname)
        print("age:",self.age)


p1=Person()
p2=Person()
print(p1)
print(p2)
print(p1.lastname)
print(p2.lastname)
print(Person.lastname)
p1.setname("윤아")
p2.setname("윤아")
p1.setage(20)
p2.setage(30)
p1.display("banana")
p2.display("banana")
# print(p1.fullname)
# print(p2.fullname)