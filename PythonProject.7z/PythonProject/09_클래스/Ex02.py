class Student:
    name ='철수'
    def __init__(self,age):
        print("init:",self,age)
        self.age = age

s1 = Student(10)
s2 = Student(20)
print(s1.name, s1.age)
print(s2.name, s2.age)

