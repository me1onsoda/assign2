
class Bank:
    rate = 0.03

    def __init__(self,deposit):
        self.deposit = deposit
        print(self.deposit,"입금")

    def calculate(self):
        self.balance = self.deposit * (self.rate+1)

    def show(self):
        print("balacne:",self.balance)

b1 = Bank(10000)
b2 = Bank(30000)
b1.calculate()
b2.calculate()
b1.show()
b2.show()
