import Ex04
service = Ex04.Service("아이린")
service.show()

from Ex04 import Service
service2 = Service("누구")
service2.show()

print("------------------------")
from Ex02 import Student
print("Ex02 Student class")
stu = Student(14)
print(stu.name, stu.age)