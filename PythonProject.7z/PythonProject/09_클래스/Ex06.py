class Super:
    def __init__(self):
        print("Super 생성자")


    def show(self):
        print("Super show")

class Sub :
    def __init__(self):
        #Super.__init__(self)  # 자식 클래스가 생성될떄 자바와는 다르게 명시하지 않으면 자동으로 부모생성자를 거치지는 않는다
        print("Sub 생성자")

    def show(self):
        Super().show()
        print("Sub show")

class Sub2(Super): #sub클래스가 Super를 상속받는다는 의미
    def __init__(self):
        print("Sub2 생성자")
        #super -> 부모 클래스명 상관없이 부모ㅓ 클래스를 지칭하는 표현
        super().__init__()
    #pass #생성자가 없을때는 자동으로 부모 생성자로 넘어감(Super.__init__(self)) 가 자동실행

    def show(self):
        Super.show(self)
        super().show()
        print("Sub2 show")



sp1 = Super()
print("-------------------------")
sp1 = Sub()
print("-------------------------")
sp2 = Sub2()
print("-------------------------")
sp1.show()
sp2.show()
