class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def show(self):
        print(self.name,self.age,end=" ")

class Employee(Person):
    def __init__(self,name,age,position,salary):
        super().__init__(name,age)
        self.position = position
        self.salary = salary

    def show(self):
        super().show()
        print(self.position,self.salary)


p1 = Person("보검",30)
p2 = Person("아이유",40)
e1 = Employee("태연",34,"대리",300)
e2 = Employee("수영",31,"사원",200)

e1.show()
e2.show()