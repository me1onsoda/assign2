class Address:
    def __init__(self):
        self.city = ""
        self.street = ""

    def setAddress(self, city, street):
        self.city = city
        self.street = street

    def showAddress(self):
        return f"{self.city} {self.street}"

class Student:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        self.address = Address()

    def setAddress(self, city, street):
        # self.address.city = city
        # self.address.street = street
        self.address.setAddress(city, street)

    def showStudent(self):
        print (f"{self.name} {self.age} {self.address.showAddress()}")


s1 = Student("서현",30)
s1.address.setAddress("서울","통일로")
s1.setAddress("서울","용산구")
s1.address.showAddress()
s1.showStudent()