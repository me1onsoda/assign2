class Product:
    def __init__(self,name,price):
        self.name=name
        self.price=price

    def printProduct(self):
        print(self.name,self.price,"원")

class Cart:
    def __init__(self):
        self.items = {} #p1,3 p2,3

    def addItem(self,product,count):
        if product in self.items:
            self.items[product] += count
        else:
            self.items[product] = count

class Customer:
    def __init__(self,name):
        self.name=name
        self.cart=Cart()

    def addCart(self,product,count):
        self.cart.addItem(product,count)

    def checkout(self):
        totalPrice = 0
        print(self.name+" 결제정보")

        for product,count in self.cart.items.items():
            productTotal = count*product.price
            print("{} * {} = {}원".format(product.name,count,productTotal))
            totalPrice += productTotal
        print("총합 : {}원".format(totalPrice))
        self.cart.items.clear()
        print()





p1 = Product("사과",1000)
p2 = Product("포도",2000)
p3 = Product("딸기",3000)
p1.printProduct() #사과//1000원
p2.printProduct()
p3.printProduct()
print()

c1 = Customer("수영") #name #cart = Cart()
c2 = Customer("정국") #name

c1.addCart(p1,3)
c1.addCart(p1,2)
c1.addCart(p2,4)

c2.addCart(p1,2)
c2.addCart(p2,5)
c2.addCart(p2,9)

c1.checkout()
c2.checkout()
#수영 결제정보
#사과 * 3 = 3000원
#포도 * 4 = 8000원
#총합 : 11000원