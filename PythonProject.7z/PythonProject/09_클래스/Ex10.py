class Lion:
    def __init__(self):
        print('Lion 생성자')
    def bite(self):
        print('Lion bite')
    def cry(self):
        print('Lion cry')

class Tiger:
    def __init__(self):
        print('Tiger 생성자')
    def jump(self):
        print('Tiger jump')
    def cry(self):
        print('Tiger cry')
    def play(self):
        print('Tiger play')

# class Liger(Tiger, Lion): 상속시 앞에 순서에따라 맨앞에 쓰여진 생성자가 호출된다
class Liger(Lion, Tiger):
    def play(self):
        print('Liger play')


l = Liger()
l.play() #자기꺼 있으면 본인 메서드 호출
l.jump() #liger에 jump가 없으니까 tiger의 메서드를 호출
l.bite() #위와 동일
l.cry() #부모 둘에게 모두 같은 함수가 있을경우에는 //맨앞에 쓰여진 함수가 호출됨 //기본적으로 맨앞에 쓰여진것이 우선 순위가 높다
