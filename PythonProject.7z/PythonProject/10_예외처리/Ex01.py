x = 3
y = 0
L = [1,2,3]

# print(x/y) #ZeroDivisionError: division by zero
# print(L[3]) #IndexError: list index out of range
# print('a'+2) #TypeError: can only concatenate str
# print(3+'b') #TypeError: unsupported operand type(s) for +: 'int' and 'str'
# print(int('a')) #ValueError: invalid literal for int() with base 10: 'a'


try:
    # print(x/y)
    # print(L[3])
    # print(3 + 'b')
    # print(int('a'))
    print("2")
except ZeroDivisionError:
    print("ZeroDivisionError")
except IndexError:
    print("IndexError")
except TypeError:
    print("TypeError")
except ValueError:
    print("ValueError")
except:
    print("except")
else:
    print("else") #예외 없을때 출력
finally:
    print("finally") #예외 있던 없던 무조건 출력