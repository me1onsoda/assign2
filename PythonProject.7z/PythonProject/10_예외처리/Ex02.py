#
#
# try:
#     a = int(input('숫자1:'))
#     b = int(input('숫자2:'))
#
#     print('a+b=', a + b)
#
# except ValueError as e:
#     print(e)
#     print("숫자로 입력해주세요.")
# finally:
#     print()


try:
    f = open("test.txt","r",encoding="utf-8")
except FileNotFoundError as e:
    print(e)
    print("파일이 존재하지않습니다.")
else:
    try:
        print(f.read())
    except UnicodeDecodeError as e:
        print(e)
        print("인코딩 에러")
finally:
    print("-------------------")

a = int(input('숫자1:'))
b = int(input('숫자2:'))

try:
    if a < 0 or b < 0:
        raise ArithmeticError('음수에러')
except ArithmeticError as e:
    print(e)
    print("음수")

