book = {}
allstop = False
while True:

    while True:
        try:
            title = input("제목입력:")
            if len(title) < 3 or len(title) > 5:
                raise TypeError("제목은 3~5글자로 입력하세요")
        except TypeError as e:
            print(e)
        else:
            break

    while True:
        try:
            price = input("가격입력:")
            price = int(price)
        except ValueError as e:
            print(e)
            print("가격은 숫자로 입력헤주세요")
        else:
            break

    book[title] = price

    while True:
        try:
            conti = input("계속?(y/n)")
            if conti != 'y':
                pass
                if conti == 'n':
                    allstop =True
                    break
                else:
                    raise TypeError("y/n중에 입력해주세요.")
        except TypeError as e:
            print(e)
        else:
            break
    if allstop == True:
        break




print(book)
