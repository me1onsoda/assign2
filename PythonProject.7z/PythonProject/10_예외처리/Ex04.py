def inputTitle(inputPurpose):
    while True:
        try:
            title = input(inputPurpose)
            if len(title) < 3 or len(title) > 5:
                raise TypeError("제목은 3~5글자로 입력하세요")
        except TypeError as e:
            print(e)
        else:
            break
    return title

def inputPrice(inputPurpose):
    while True:
        try:
            price = int(input(inputPurpose))
        except ValueError as e:
            print(e)
            print("가격은 숫자로 입력헤주세요")
        else:
            break
    return price

def mainmenu():
    print("Menu Select")
    print("1. 전체조회")
    print("2. 추가")
    print("3. 수정")
    print("4. 삭제")
    print("0. 종료")

def diplayBook():
    if len(book) != 0:
        print("제목\t가격")
        for title, price in book.items():
            print("{}\t{}".format(title, price))
    else:
        print("현재 저장된 정보가 없습니다.")

def insertBook():
    title = inputTitle("제목입력:")
    price = inputPrice("가격입력:")
    book[title] = price

def updateBook():
    if len(book) != 0:
        while True:
            searchbook = input("수정하려는 책 제목을 입력해주세요")
            if searchbook in book.keys():
                break
            else:
                print("파일에 없는 제목입니다. 다시 입력하세요.")

        while True:
            try:
                updateprice = int(input("수정할 가격:"))
            except ValueError as e:
                print(e)
                print("가격은 숫자로 입력헤주세요")
            else:
                break

        book[searchbook] = updateprice
    else:
        print("현재 저장된 정보가 없습니다.")

def deleteBook():
    if len(book) != 0:
        while True:
            deletetitle = input("삭제할 책 제목을 입력해주세요:")
            if deletetitle in book.keys():
                break
            else:
                print("파일에 없는 제목입니다. 다시 입력하세요.")
        book.pop(deletetitle)
    else:
        print("현재 저장된 정보가 없습니다.")

book = {}

while True:
    mainmenu()
    try:
        menu = int(input("메류를 선택해주세요 >> "))
    except ValueError:
       print("숫자로 입력해주세요")
       continue

    match menu:
        case 0:
            break
        case 1:
            diplayBook()
        case 2:
            insertBook()
        case 3:
            updateBook()
        case 4:
            deleteBook()
        case _:
            print("없는 메뉴 번호입니다.")







