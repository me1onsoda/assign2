import re
from unittest import result

L = ['ab123','cd456','xy789','12ef345qw','abc12','ab12343']

#문자열 2개 + 숫자3

# regex = re.compile(r'^[a-zA-z]{2}\d{3}$') #^시작 $끝
regex = re.compile(r'[a-zA-z]{2}\d{3}')
for item in L:

    # print(regex.match(item))
    if regex.match(item): #match는 오직 문자열의 처음(0번 인덱스)부터 패턴이 일치하는지 검사
    # if re.match(regex, item): #위와동일
    # if regex.search(item): #search는 문자열의 '어디든(처음, 중간, 끝)' 상관없이 패턴과 일치하는 부분이 포함되있는걸 찾는것
        print('%s는 패턴일치' % item)
        print(regex.search(item).start(), regex.search(item).end())
    else:
        print('%s는 패턴불일치' % item)
print()

L = {'a.txt', 'a12.txt', 'a123.txt', 'a12345.txt'}

#a 이후 숫자 3개 이상인것

regex = re.compile(r'[a]{1}\d{3,}')
for item in L:
    if regex.match(item):
        print('%s는 패턴일치' % item)
        print(regex.search(item).start(), regex.search(item).end())
    else:
        print('%s는 패턴불일치' % item)

L = ["hello!","hello안녕~","하하하","안녕^^","반갑습니다.","또 만나요","파이썬","grape"]
regex = re.compile(r'[가-힣]+')#+ 1글자 이상~  #?0번 또는 1번  #* 0글자 이상~
for item in L:
    # if regex.search(item):
    if regex.fullmatch(item):
        print('%s는 패턴일치' % item)
        print(regex.search(item).start(), regex.search(item).end())
    else:
        print('%s는 패턴불일치' % item)

print("_---------------------------------")

for item in L:
    # for han in regex.findall(item):
    for han in re.findall(regex, item):
        if han != '':
            print(han)


print("_---------------------------------")

result = [word for word in L if re.fullmatch('[가-힣]+',word)]
print(result)

print("_---------------------------------")

print(re.findall(regex, '안녕123 하세요!!! hello'))
print(re.sub('\s+',' ','      안녕    하세요   여러분  '))


print("_---------------------------------")

for item in L:
    han_list = regex.findall(item)
    if han_list:
        print(" ".join(han_list))


print("_---------------------------------")

mailList = ['abc@naver.com','xyz@daum.net','qwer@google.com']
regexid = re.compile(r'(.*)@')
regexmail = re.compile(r'@(.*)')

for item in mailList:
    print("아이디:"+re.findall(regexid, item)[0],end=' ')
    print("도메인:"+re.findall(regexmail, item)[0])

print("_---------------------------------")

for item in mailList:
    temp = re.sub('@', " 도메인:", item)
    temp = "아이디:" + temp
    print(temp)

print("_---------------------------------")

regex = re.compile('@')
for item in mailList:
    result = regex.search(item)
    if regex.search(item):
        id = item[0:result.start()]
        domian = item[result.end():]
        print(id+domian)

print("_----------------------------------")

text='홍길동, 30세'
regex = re.compile(r'(.+),\s(\d+)세')
match = regex.fullmatch(text)
if match:
    print(match.groups())
    print(match)
    print("이름:",match.group(1))
    print("나이:",match.group(2))

print("---------------------------------------")

address = "서울시 은평구 녹번동 219-47"
address = "서울특별시 강남구 역삼동 123-45"
regex = re.compile(r'(.+시)\s(.+구)\s(.+동)\s(\d{3}-\d{2})')
match = regex.fullmatch(address)
if match:
    print(match.groups())
    print(match)
    print(match.groups(0))
    print("시:", match.group(1))
    print("구:", match.group(2))
    print("동:", match.group(3))
    print("번지:", match.group(4))


print("---------------------------------------")

date = "오늘은 2025-10-23 입니다."
regex = re.compile(r'.+\s(\d{4})-(\d+)-(\d+)\s.+')
match = regex.fullmatch(date)
if match:
    print("연:", match.group(1),"년")
    print("월:", match.group(2),"월")
    print("일:", match.group(3),"일")

print("---------------------------------------")

f = open("score.txt","r",encoding="utf-8")

regex = re.compile(r'([가-힣]+)\s(\d+)\s(\d+)\s(\d+)')
for line in f.readlines():
    match = regex.search(line)
    if match:
        totalscore = int(match.group(2)) + int(match.group(3)) + int(match.group(4))
        print("{} - 합계: {}".format(match.group(1),totalscore))
