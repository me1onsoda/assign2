def inputTitle(inputPurpose):
    title = input(inputPurpose)
    return title

def inputPrice(inputPurpose):
    while True:
        try:
            price = int(input(inputPurpose))
        except ValueError as e:
            print(e)
            print("가격은 숫자로 입력헤주세요")
        else:
            break
    return price

def mainmenu():
    print("[도서 관리 시스템]")
    print("1. 도서 등록")
    print("2. 전체 도서 보기")
    print("3. 도서 검색")
    print("4. 도서 삭제")
    print("5. 도서 가격 수정")
    print("6. 파일 저장")
    print("7. 종료")

def diplayBook():
    if len(bookList) != 0:
        print("전체 도서")
        for book in bookList:
            for key, value in book.items():
                print("{} : {}".format(key, value),end=" ")
            print()
    else:
        print("현재 저장된 정보가 없습니다.")

def insertBook():
    book = {}
    title = input("도서제목:")
    author = input("저자:")
    price = inputPrice("가격(숫자만):")
    book["제목"] = title
    book["저자"] = author
    book["가격"] = price
    bookList.append(book)
    print("책이 등록되었습니다.")

def searchBook():
    titlekeyword = input("검색할 도서 제목 키워드:")
    print("'{}' 검색결과".format(titlekeyword))
    for book in bookList:
        if book["제목"] in titlekeyword:
            for book in bookList:
                for key, value in book.items():
                    print("{} : {}".format(key, value), end=" ")
                print()
        else:
            print("검색 결과 없음")

def updateBook():
    if len(bookList) != 0:
        while True:
            found = False
            targetbook = None
            searchbook = input("수정하려는 책 제목을 입력해주세요")

            for book in bookList:
                if book["제목"] == searchbook:
                    found = True
                    targetbook = book
                    break
            if found:
                break
            else:
                print("없는 제목입니다. 다시 입력해주세요.")

        while True:
            try:
                updateprice = int(input("수정할 가격:"))
                targetbook["가격"] = updateprice
            except ValueError as e:
                print(e)
                print("가격은 숫자로 입력헤주세요")
            else:
                break


    else:
        print("현재 저장된 정보가 없습니다.")

def deleteBook():
    if len(bookList) != 0:
        while True:
            found = False
            targetbook = None
            searchbook = input("삭제하려는 책 제목을 입력해주세요")

            for book in bookList:
                if book["제목"] == searchbook:
                    found = True
                    targetbook = book
                    break
            if found:
                break
            else:
                print("없는 제목입니다. 다시 입력해주세요.")
        bookList.remove(targetbook)
    else:
        print("현재 저장된 정보가 없습니다.")

def savefile():
    fw = open("bookList.json", "w", encoding="utf-8")
    for book in bookList:
        line = f"제목: {book['제목']} |  저자: {book['저자']} |  가격: {book['저자']}원\n"
        fw.write(line)

bookList = []
# fr = open("booklist.json", "r", encoding="utf-8")
# fr.readline()

while True:
    mainmenu()
    try:
        menu = int(input("메류를 선택해주세요 >> "))
    except ValueError:
       print("숫자로 입력해주세요")
       continue

    match menu:
        case 1:
            insertBook()
        case 2:
            diplayBook()
        case 3:
            searchBook()
            pass
        case 4:
            deleteBook()
            pass
        case 5:
            updateBook()
        case 6:
            savefile()
        case 7:
            break
        case _:
            print("없는 메뉴 번호입니다.")




#a검색시 a aa aaaa 다 나오게
#없으면 없다고
#찾았으면 가격수정 (정규표현식으로 3~4자리만입력가능하게)
#'--'이 수정되었습니다
#마지막에 파일저장 형식은 자유

#첫 실행시에 자료 불러오기
#최초에는 없고 파일저장이후 실행해볼때는 가져올수있게




