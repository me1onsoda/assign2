package com.example.Ex02.dto;

import lombok.Data;

@Data
public class TagDto {
    private Long tagId;
    private String tagName;
}